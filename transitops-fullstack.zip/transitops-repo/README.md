# TransitOps — Smart Transport Operations Platform

A full-stack transport operations platform: vehicle registry, driver management,
trip dispatch, maintenance workflow, fuel & expense tracking, and analytics —
with role-based access control (RBAC).

```
transitops/
├── backend/     Node.js + Express REST API (JWT auth, business rules, in-memory store)
└── frontend/    Plain HTML / CSS / JS client (index.html, style.css, script.js)
```

## Quick start

### 1. Run the backend

```bash
cd backend
npm install
cp .env.example .env
npm start
```

The API starts at `http://localhost:4000`. Health check: `GET http://localhost:4000/api/health`.

### 2. Run the frontend

The frontend is plain static files — no build step. Easiest option, serve it so
the browser treats it as a proper origin:

```bash
cd frontend
npx serve .
# or: python3 -m http.server 5500
```

Then open the printed URL (e.g. `http://localhost:5500`). You can also just
double-click `frontend/index.html` — it works from `file://` too, since the
backend allows all origins (`CORS_ORIGIN=*`) in dev mode.

If your backend runs somewhere other than `http://localhost:4000`, edit the
`API_BASE` line at the bottom of `frontend/index.html`:

```html
<script>window.TRANSITOPS_API_BASE = "http://localhost:4000/api";</script>
```

### 3. Log in

Use any of the seeded demo accounts (password for all: `demo1234`):

| Role | Email |
|---|---|
| Fleet Manager | fleet.manager@transitops.io |
| Driver | driver@transitops.io |
| Safety Officer | safety@transitops.io |
| Financial Analyst | finance@transitops.io |

The login screen has one-click buttons that fill these in for you.

## What's implemented

- **Auth & RBAC** — JWT login; each role only sees/edits the modules it's allowed to (see `backend/data/roles.js`).
- **Vehicle Registry** — CRUD, unique registration number enforced server-side.
- **Driver Management** — CRUD, license expiry & status tracked.
- **Trip lifecycle** — Draft → Dispatched → Completed → Cancelled, with all business rules enforced in the API:
  - Retired / In Shop vehicles excluded from dispatch
  - Suspended / expired-license drivers excluded from dispatch
  - A vehicle or driver already On Trip can't be assigned again
  - Cargo weight can't exceed vehicle max load
  - Dispatch/complete/cancel automatically flips vehicle & driver status
- **Maintenance** — opening a record forces the vehicle to "In Shop"; closing it restores "Available" (unless Retired).
- **Fuel & Expenses** — logging, plus automatic total operational cost (fuel + maintenance) per vehicle.
- **Reports & Analytics** — fuel efficiency, fleet utilization, operational cost, ROI, CSV export.
- **Bonus** — search/filter/sort, dark/light mode, hand-rolled charts (no chart library dependency), responsive layout, license-expiry compliance watch.

## Notes for pushing to GitHub

- `backend/.env` is git-ignored (secrets); `backend/.env.example` is committed as a template.
- The data store (`backend/data/store.js`) is in-memory and resets whenever the server restarts.
  To persist data, swap it for a real database (Postgres/MongoDB) behind the same exported shape.
- Not implemented (flagged as optional in the brief): PDF export, license-expiry emails, document uploads.

## Tech stack

- **Backend:** Node.js, Express, JWT (`jsonwebtoken`), `bcryptjs` for password hashing, in-memory data store
- **Frontend:** Vanilla HTML/CSS/JS (no framework, no build step), `fetch()` against the REST API
