const express = require('express');
const { trips, vehicles, drivers, fuelLogs, nextId } = require('../data/store');
const { authenticateToken, requireView, requireWrite } = require('../middleware/auth');

const router = express.Router();
router.use(authenticateToken, requireView('trips'));

function daysUntil(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.round((d - now) / 86400000);
}

// GET /api/trips
router.get('/', (req, res) => {
  res.json(trips);
});

// POST /api/trips  -> creates a Draft trip
router.post('/', requireWrite('trips'), (req, res) => {
  const { source, destination, vehicleId, driverId, cargoWeight, plannedDistance, revenue } = req.body || {};
  if (!source || !destination || !vehicleId || !driverId || !cargoWeight || !plannedDistance) {
    return res.status(400).json({ error: 'source, destination, vehicleId, driverId, cargoWeight and plannedDistance are required' });
  }
  const vehicle = vehicles.find((v) => v.id === vehicleId);
  const driver = drivers.find((d) => d.id === driverId);
  if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });
  if (!driver) return res.status(404).json({ error: 'Driver not found' });
  if (Number(cargoWeight) > vehicle.maxLoad) {
    return res.status(422).json({ error: `Cargo weight (${cargoWeight} kg) exceeds vehicle max load (${vehicle.maxLoad} kg)` });
  }

  const trip = {
    id: nextId('TRP', 'trp'),
    source, destination, vehicleId, driverId,
    cargoWeight: Number(cargoWeight),
    plannedDistance: Number(plannedDistance),
    revenue: Number(revenue) || 0,
    status: 'Draft',
    finalOdometer: null,
    fuelConsumed: null,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  trips.push(trip);
  res.status(201).json(trip);
});

// POST /api/trips/:id/dispatch
router.post('/:id/dispatch', requireWrite('trips'), (req, res) => {
  const trip = trips.find((t) => t.id === req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  if (trip.status !== 'Draft') return res.status(409).json({ error: `Trip is not in Draft status (currently ${trip.status})` });

  const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
  const driver = drivers.find((d) => d.id === trip.driverId);

  if (vehicle.status === 'In Shop' || vehicle.status === 'Retired') {
    return res.status(422).json({ error: 'Vehicle is not eligible for dispatch (In Shop / Retired)' });
  }
  if (vehicle.status === 'On Trip') return res.status(422).json({ error: 'Vehicle is already on another trip' });
  if (driver.status === 'Suspended') return res.status(422).json({ error: 'Driver is suspended' });
  if (daysUntil(driver.licenseExpiry) < 0) return res.status(422).json({ error: "Driver's license has expired" });
  if (driver.status === 'On Trip') return res.status(422).json({ error: 'Driver is already on another trip' });
  if (trip.cargoWeight > vehicle.maxLoad) return res.status(422).json({ error: 'Cargo weight exceeds vehicle capacity' });

  trip.status = 'Dispatched';
  vehicle.status = 'On Trip';
  driver.status = 'On Trip';
  res.json({ trip, vehicle, driver });
});

// POST /api/trips/:id/complete  { finalOdometer, fuelConsumed }
router.post('/:id/complete', requireWrite('trips'), (req, res) => {
  const trip = trips.find((t) => t.id === req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  if (trip.status !== 'Dispatched') return res.status(409).json({ error: `Trip is not Dispatched (currently ${trip.status})` });

  const { finalOdometer, fuelConsumed } = req.body || {};
  const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
  const driver = drivers.find((d) => d.id === trip.driverId);

  if (finalOdometer === undefined || fuelConsumed === undefined) {
    return res.status(400).json({ error: 'finalOdometer and fuelConsumed are required' });
  }
  if (Number(finalOdometer) < vehicle.odometer) {
    return res.status(422).json({ error: 'Final odometer cannot be less than the current odometer' });
  }

  trip.status = 'Completed';
  trip.finalOdometer = Number(finalOdometer);
  trip.fuelConsumed = Number(fuelConsumed);
  vehicle.status = 'Available';
  vehicle.odometer = Number(finalOdometer);
  driver.status = 'Available';

  const fuelLog = {
    id: nextId('FUE', 'fue'),
    vehicleId: vehicle.id,
    liters: Number(fuelConsumed),
    cost: Math.round(Number(fuelConsumed) * 110),
    date: new Date().toISOString().slice(0, 10),
  };
  fuelLogs.push(fuelLog);

  res.json({ trip, vehicle, driver, fuelLog });
});

// POST /api/trips/:id/cancel
router.post('/:id/cancel', requireWrite('trips'), (req, res) => {
  const trip = trips.find((t) => t.id === req.params.id);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  if (trip.status !== 'Dispatched' && trip.status !== 'Draft') {
    return res.status(409).json({ error: `Trip cannot be cancelled from status ${trip.status}` });
  }

  const wasDispatched = trip.status === 'Dispatched';
  trip.status = 'Cancelled';

  if (wasDispatched) {
    const vehicle = vehicles.find((v) => v.id === trip.vehicleId);
    const driver = drivers.find((d) => d.id === trip.driverId);
    vehicle.status = 'Available';
    driver.status = 'Available';
  }
  res.json({ trip });
});

module.exports = router;
