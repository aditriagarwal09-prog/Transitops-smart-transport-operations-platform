const express = require('express');
const { vehicles, trips, nextId } = require('../data/store');
const { authenticateToken, requireView, requireWrite } = require('../middleware/auth');

const router = express.Router();
router.use(authenticateToken, requireView('vehicles'));

// GET /api/vehicles
router.get('/', (req, res) => {
  res.json(vehicles);
});

// POST /api/vehicles
router.post('/', requireWrite('vehicles'), (req, res) => {
  const { regNo, name, type, region, maxLoad, odometer, acqCost, status } = req.body || {};
  if (!regNo || !name || !maxLoad) {
    return res.status(400).json({ error: 'regNo, name and maxLoad are required' });
  }
  const dupe = vehicles.find((v) => v.regNo.toLowerCase() === String(regNo).toLowerCase());
  if (dupe) return res.status(409).json({ error: 'Registration number must be unique' });

  const vehicle = {
    id: nextId('VEH', 'veh'),
    regNo, name,
    type: type || 'Truck',
    region: region || 'North',
    maxLoad: Number(maxLoad),
    odometer: Number(odometer) || 0,
    acqCost: Number(acqCost) || 0,
    status: status || 'Available',
  };
  vehicles.push(vehicle);
  res.status(201).json(vehicle);
});

// PUT /api/vehicles/:id
router.put('/:id', requireWrite('vehicles'), (req, res) => {
  const vehicle = vehicles.find((v) => v.id === req.params.id);
  if (!vehicle) return res.status(404).json({ error: 'Vehicle not found' });

  const { regNo } = req.body || {};
  if (regNo) {
    const dupe = vehicles.find((v) => v.regNo.toLowerCase() === String(regNo).toLowerCase() && v.id !== vehicle.id);
    if (dupe) return res.status(409).json({ error: 'Registration number must be unique' });
  }
  Object.assign(vehicle, req.body);
  res.json(vehicle);
});

// DELETE /api/vehicles/:id
router.delete('/:id', requireWrite('vehicles'), (req, res) => {
  const idx = vehicles.findIndex((v) => v.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Vehicle not found' });

  const inUse = trips.some((t) => t.vehicleId === req.params.id && t.status === 'Dispatched');
  if (inUse) return res.status(409).json({ error: 'Cannot delete: vehicle is on an active trip' });

  vehicles.splice(idx, 1);
  res.status(204).end();
});

module.exports = router;
