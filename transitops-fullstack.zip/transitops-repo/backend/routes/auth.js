const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { users } = require('../data/store');
const { ROLES } = require('../data/roles');
const { authenticateToken, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '12h';

// POST /api/auth/login  { email, password } -> { token, user }
router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required' });

  const user = users.find((u) => u.email.toLowerCase() === String(email).toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const payload = { id: user.id, email: user.email, name: user.name, role: user.role };
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
  res.json({ token, user: { ...payload, roleLabel: ROLES[user.role].label, tabs: ROLES[user.role].tabs } });
});

// GET /api/auth/me -> current user (validates token is still good)
router.get('/me', authenticateToken, (req, res) => {
  res.json({ user: { ...req.user, roleLabel: ROLES[req.user.role].label, tabs: ROLES[req.user.role].tabs } });
});

// GET /api/auth/demo-accounts -> list of demo emails for the login screen (no secrets)
router.get('/demo-accounts', (req, res) => {
  res.json({
    password: 'demo1234',
    accounts: users.map((u) => ({ email: u.email, name: u.name, role: u.role, roleLabel: ROLES[u.role].label })),
  });
});

module.exports = router;
