const express = require('express');
const { vehicles, drivers, trips, maintenance, fuelLogs } = require('../data/store');
const { authenticateToken, requireView } = require('../middleware/auth');

const router = express.Router();
router.use(authenticateToken);

function daysUntil(dateStr) {
  const d = new Date(dateStr);
  const now = new Date();
  return Math.round((d - now) / 86400000);
}

function computeReport() {
  return vehicles.map((v) => {
    const logs = fuelLogs.filter((f) => f.vehicleId === v.id);
    const totalFuel = logs.reduce((s, f) => s + f.liters, 0);
    const fuelCost = logs.reduce((s, f) => s + f.cost, 0);
    const maintCost = maintenance.filter((m) => m.vehicleId === v.id).reduce((s, m) => s + m.cost, 0);
    const completedTrips = trips.filter((t) => t.vehicleId === v.id && t.status === 'Completed');
    const totalDistance = completedTrips.reduce((s, t) => s + (t.plannedDistance || 0), 0);
    const revenue = completedTrips.reduce((s, t) => s + (t.revenue || 0), 0);
    const opCost = fuelCost + maintCost;
    const fuelEfficiency = totalFuel > 0 ? totalDistance / totalFuel : 0;
    const roi = v.acqCost > 0 ? ((revenue - opCost) / v.acqCost) * 100 : 0;
    return {
      vehicleId: v.id, regNo: v.regNo, name: v.name,
      totalFuel, fuelCost, maintCost, totalDistance, revenue, opCost,
      fuelEfficiency: Number(fuelEfficiency.toFixed(2)),
      roi: Number(roi.toFixed(2)),
    };
  });
}

// GET /api/reports  -> per-vehicle analytics + fleet-wide summary
router.get('/', requireView('reports'), (req, res) => {
  const perVehicle = computeReport();
  const activeV = vehicles.filter((v) => v.status !== 'Retired').length;
  const onTripV = vehicles.filter((v) => v.status === 'On Trip').length;
  const utilization = activeV ? Math.round((onTripV / activeV) * 100) : 0;

  res.json({
    utilization,
    totalFuelCost: perVehicle.reduce((s, d) => s + d.fuelCost, 0),
    totalMaintenanceCost: perVehicle.reduce((s, d) => s + d.maintCost, 0),
    totalOperationalCost: perVehicle.reduce((s, d) => s + d.opCost, 0),
    statusMix: vehicles.reduce((acc, v) => { acc[v.status] = (acc[v.status] || 0) + 1; return acc; }, {}),
    perVehicle,
  });
});

// GET /api/reports/export -> CSV file download
router.get('/export', requireView('reports'), (req, res) => {
  const rows = computeReport();
  const header = ['Vehicle RegNo', 'Vehicle Name', 'Fuel Efficiency (km/L)', 'Total Distance (km)', 'Fuel Cost', 'Maintenance Cost', 'Operational Cost', 'Revenue', 'ROI (%)'];
  const csvLines = [header.join(',')];
  rows.forEach((d) => {
    csvLines.push([d.regNo, d.name, d.fuelEfficiency, d.totalDistance, d.fuelCost, d.maintCost, d.opCost, d.revenue, d.roi].join(','));
  });
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="transitops_report.csv"');
  res.send(csvLines.join('\n'));
});

// GET /api/reports/dashboard -> KPI summary for the dashboard view
router.get('/dashboard', requireView('dashboard'), (req, res) => {
  const totalV = vehicles.length;
  const activeV = vehicles.filter((v) => v.status !== 'Retired').length;
  const availV = vehicles.filter((v) => v.status === 'Available').length;
  const shopV = vehicles.filter((v) => v.status === 'In Shop').length;
  const onTripV = vehicles.filter((v) => v.status === 'On Trip').length;
  const activeTrips = trips.filter((t) => t.status === 'Dispatched').length;
  const pendingTrips = trips.filter((t) => t.status === 'Draft').length;
  const driversOnDuty = drivers.filter((d) => d.status === 'On Trip' || d.status === 'Available').length;
  const utilization = activeV ? Math.round((onTripV / activeV) * 100) : 0;

  const licenseWatch = drivers
    .map((d) => ({ ...d, daysLeft: daysUntil(d.licenseExpiry) }))
    .sort((a, b) => a.daysLeft - b.daysLeft);

  res.json({
    totalVehicles: totalV, activeVehicles: activeV, availableVehicles: availV,
    inMaintenance: shopV, activeTrips, pendingTrips, driversOnDuty,
    totalDrivers: drivers.length, fleetUtilization: utilization,
    licenseWatch,
    recentTrips: [...trips].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5),
  });
});

module.exports = router;
