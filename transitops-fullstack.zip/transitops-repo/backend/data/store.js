/**
 * In-memory data store for TransitOps.
 *
 * This keeps the hackathon build simple and dependency-free (no DB setup
 * required to run the project). Swap this module for a real database
 * (Postgres/Mongo) by re-implementing the same exported shape.
 */
const bcrypt = require('bcryptjs');

const DEMO_PASSWORD_HASH = bcrypt.hashSync('demo1234', 8);

const users = [
  { id: 'USR-001', email: 'fleet.manager@transitops.io', name: 'Priya Nair', role: 'fleet_manager', passwordHash: DEMO_PASSWORD_HASH },
  { id: 'USR-002', email: 'driver@transitops.io', name: 'Alex Romero', role: 'driver', passwordHash: DEMO_PASSWORD_HASH },
  { id: 'USR-003', email: 'safety@transitops.io', name: 'Sana Malik', role: 'safety_officer', passwordHash: DEMO_PASSWORD_HASH },
  { id: 'USR-004', email: 'finance@transitops.io', name: 'Devon Cole', role: 'financial_analyst', passwordHash: DEMO_PASSWORD_HASH },
];

const vehicles = [
  { id: 'VEH-001', regNo: 'UP16-AB-4521', name: 'Tata Ace Gold', type: 'Mini Truck', maxLoad: 750, odometer: 18420, acqCost: 620000, status: 'Available', region: 'North' },
  { id: 'VEH-002', regNo: 'DL8C-XY-1190', name: 'Ashok Leyland Dost+', type: 'LCV', maxLoad: 1250, odometer: 41200, acqCost: 980000, status: 'On Trip', region: 'North' },
  { id: 'VEH-003', regNo: 'MH12-KJ-7723', name: 'Mahindra Bolero Pik-Up', type: 'Pickup', maxLoad: 900, odometer: 65310, acqCost: 740000, status: 'In Shop', region: 'West' },
  { id: 'VEH-004', regNo: 'KA05-MN-3305', name: 'Eicher Pro 2049', type: 'Truck', maxLoad: 3200, odometer: 112400, acqCost: 2150000, status: 'Available', region: 'South' },
  { id: 'VEH-005', regNo: 'Van-05', name: 'Force Traveller', type: 'Van', maxLoad: 500, odometer: 9100, acqCost: 540000, status: 'Available', region: 'North' },
  { id: 'VEH-006', regNo: 'RJ14-PT-9081', name: 'Tata 407 Gold', type: 'Mini Truck', maxLoad: 1600, odometer: 88220, acqCost: 890000, status: 'Retired', region: 'West' },
];

const drivers = [
  { id: 'DRV-001', name: 'Alex Romero', licenseNo: 'DL-0421-9981', licenseCategory: 'LMV-TR', licenseExpiry: '2027-03-15', contact: '+91 98110 22341', safetyScore: 92, status: 'Available' },
  { id: 'DRV-002', name: 'Meera Iyer', licenseNo: 'DL-0392-1187', licenseCategory: 'HMV', licenseExpiry: '2026-08-02', contact: '+91 99001 44210', safetyScore: 88, status: 'On Trip' },
  { id: 'DRV-003', name: 'Farhan Sheikh', licenseNo: 'DL-0217-5502', licenseCategory: 'HMV', licenseExpiry: '2025-11-20', contact: '+91 90210 66781', safetyScore: 74, status: 'Available' },
  { id: 'DRV-004', name: 'Ritu Chawla', licenseNo: 'DL-0501-7734', licenseCategory: 'LMV-TR', licenseExpiry: '2026-12-30', contact: '+91 97350 11289', safetyScore: 81, status: 'Suspended' },
  { id: 'DRV-005', name: 'Kabir Anand', licenseNo: 'DL-0665-2290', licenseCategory: 'HMV', licenseExpiry: '2028-01-10', contact: '+91 98700 33012', safetyScore: 95, status: 'Off Duty' },
];

const trips = [
  { id: 'TRP-0001', source: 'Delhi Hub', destination: 'Jaipur DC', vehicleId: 'VEH-002', driverId: 'DRV-002', cargoWeight: 1050, plannedDistance: 280, status: 'Dispatched', revenue: 18500, finalOdometer: null, fuelConsumed: null, createdAt: '2026-07-08' },
  { id: 'TRP-0002', source: 'Gurugram WH', destination: 'Chandigarh DC', vehicleId: 'VEH-001', driverId: 'DRV-001', cargoWeight: 600, plannedDistance: 250, status: 'Completed', revenue: 15200, finalOdometer: 18420, fuelConsumed: 32, createdAt: '2026-07-02' },
  { id: 'TRP-0003', source: 'Bengaluru Yard', destination: 'Chennai DC', vehicleId: 'VEH-004', driverId: 'DRV-005', cargoWeight: 2800, plannedDistance: 350, status: 'Completed', revenue: 41000, finalOdometer: 112400, fuelConsumed: 96, createdAt: '2026-06-28' },
  { id: 'TRP-0004', source: 'Pune Depot', destination: 'Nashik DC', vehicleId: 'VEH-003', driverId: 'DRV-003', cargoWeight: 700, plannedDistance: 180, status: 'Cancelled', revenue: 0, finalOdometer: null, fuelConsumed: null, createdAt: '2026-07-05' },
];

const maintenance = [
  { id: 'MNT-001', vehicleId: 'VEH-003', type: 'Engine Overhaul', description: 'Timing belt + gasket replacement', cost: 24500, status: 'Active', date: '2026-07-10' },
  { id: 'MNT-002', vehicleId: 'VEH-002', type: 'Oil Change', description: 'Routine 10k service', cost: 3200, status: 'Closed', date: '2026-06-20' },
];

const fuelLogs = [
  { id: 'FUE-001', vehicleId: 'VEH-001', liters: 32, cost: 3520, date: '2026-07-02' },
  { id: 'FUE-002', vehicleId: 'VEH-004', liters: 96, cost: 10560, date: '2026-06-28' },
  { id: 'FUE-003', vehicleId: 'VEH-002', liters: 45, cost: 4950, date: '2026-07-08' },
];

const expenses = [
  { id: 'EXP-001', vehicleId: 'VEH-001', type: 'Toll', amount: 640, date: '2026-07-02', note: 'NH48 toll plaza' },
  { id: 'EXP-002', vehicleId: 'VEH-004', type: 'Parking', amount: 300, date: '2026-06-28', note: 'Chennai DC overnight' },
];

const seq = { veh: 7, drv: 6, trp: 5, mnt: 3, fue: 4, exp: 3, usr: 5 };
function nextId(prefix, key) {
  const n = String(seq[key]++).padStart(3, '0');
  return `${prefix}-${n}`;
}

module.exports = {
  users,
  vehicles,
  drivers,
  trips,
  maintenance,
  fuelLogs,
  expenses,
  nextId,
};
